"""
PUBLIC EDITION stand-in for the competition bot.

The real bot/agent.py is left out of the published web app so its strategy isn't public before the
competition. This stand-in plays a simple, solid style (position-aware opens, push/fold when short,
equity vs pot odds after the flop) so practice games are still meaningful. It is deliberately weaker.
"""
from __future__ import annotations

import random

from arena.bluffing import STYLES, BluffBrain
from arena.engine import CALL, CHECK, FOLD, RAISE, Action
from bot.tables import postflop_equity, preflop_pct, preflop_vs_top


class Params:   # kept so imports that expect it still work
    pass


class NoLimitAgent:
    name = "nolimit"

    def __init__(self, seed=None, params=None):
        self.rng = random.Random(seed)
        self.brain = BluffBrain(STYLES["stand-in"], random.Random((seed or 0) + 11))

    def new_table(self, seat, n):
        self.seat = seat

    def _raise(self, obs, to):
        if RAISE not in obs.legal:
            return Action(CALL) if CALL in obs.legal else Action(CHECK)
        return Action(RAISE, int(max(obs.min_raise_to, min(obs.max_raise_to, to))))

    def _passive(self, obs):
        return Action(CHECK) if CHECK in obs.legal else Action(CALL)

    def _fold(self, obs):
        return Action(CHECK) if CHECK in obs.legal else Action(FOLD)

    def act(self, obs):
        try:
            return self.brain.maybe_bluff(obs, self._act(obs))
        except Exception:
            return self._fold(obs)

    def _act(self, obs):
        bb = obs.bb
        stack_bb = (obs.my_stack + obs.my_bet) / bb
        if obs.street == 0:
            pct = preflop_pct(obs.hole)
            raised = any(a.kind == RAISE for st, _, a in obs.history if st == 0)
            if stack_bb <= 10:
                return self._raise(obs, obs.max_raise_to) if pct >= 0.70 else self._fold(obs)
            if not raised:
                cut = 0.80 - 0.04 * max(0, 4 - len(obs.to_act_after))
                return self._raise(obs, obs.my_bet + obs.to_call + 2.5 * bb) if pct >= cut else self._passive(obs) if obs.to_call == 0 else self._fold(obs)
            eq = preflop_vs_top(obs.hole, 20.0)
            if eq >= 0.60:
                return self._raise(obs, 3 * (obs.my_bet + obs.to_call))
            odds = obs.to_call / (obs.pot + obs.to_call)
            return Action(CALL) if eq >= odds + 0.08 and obs.to_call <= 0.15 * obs.my_stack else self._fold(obs)
        n = max(1, sum(obs.in_hand) - 1)
        eq = postflop_equity(obs.hole, obs.board, n)
        if obs.to_call == 0:
            if eq >= 0.65 or (eq >= 0.45 and self.rng.random() < 0.3):
                return self._raise(obs, 0.6 * obs.pot)
            return Action(CHECK)
        b = obs.to_call / max(1, obs.pot - obs.to_call)
        eq_adj = eq ** (1.0 + 0.9 * min(b, 2.0))
        odds = obs.to_call / (obs.pot + obs.to_call)
        if eq_adj >= 0.8:
            return self._raise(obs, obs.my_bet + obs.to_call + obs.pot)
        return Action(CALL) if eq_adj >= odds + 0.04 else self._fold(obs)
