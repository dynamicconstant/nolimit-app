"""
Keating-inspired arena opponent (training/evaluation only; never part of the submission).

Each decision:
  1. map the observation to a model situation and read P(fold / passive / aggressive)
  2. rank the hand within that situation (preflop percentile; postflop equity quantile)
  3. with probability `unpredictability` ignore hand strength and sample the distribution;
     otherwise strong hands take the aggressive slice, weak hands the fold slice
  4. size aggressive actions by sampling the model's size distribution

Steps 2-3 (how strength maps to action) and the size values inside each bin are ASSUMPTIONS:
the data needed to measure them (hole cards on every decision) only exist for shown-down hands.
"""
from __future__ import annotations

import bisect
import random
from typing import Dict, List

from arena.engine import CALL, CHECK, FOLD, RAISE, Action
from bot.tables import postflop_equity, preflop_pct, tables

from .model import ACTIONS, SIZE_BINS, load_model, situation_key

STREETS = ("preflop", "flop", "turn", "river")
PRE_UNOPENED_BB = (2.2, 3.0, 4.2, 6.0)     # raise-to, in big blinds, for size bins 0..3
PRE_MULTIPLE = (2.2, 3.0, 4.2, 6.0)        # raise-to as a multiple of the raise faced
POST_FRACTION = (0.3, 0.6, 1.0, 1.6)       # increment as a fraction of the pot after calling

_MODEL = None
_EQ_CDF: Dict[int, List[float]] = {}


def _model():
    global _MODEL
    if _MODEL is None:
        _MODEL = load_model()
    return _MODEL


def _eq_quantile(street: int, eq: float) -> float:
    """Fraction of random hands with lower heads-up equity on this street (from table counts)."""
    if street not in _EQ_CDF:
        rows = sorted((v[0], v[3]) for v in tables()["post"][street].values())
        total = sum(c for _, c in rows)
        xs, acc, cdf = [], 0, []
        for e, c in rows:
            acc += c
            xs.append(e)
            cdf.append(acc / total)
        _EQ_CDF[street] = (xs, cdf)
    xs, cdf = _EQ_CDF[street]
    i = bisect.bisect_right(xs, eq)
    return cdf[i - 1] if i else 0.0


class KeatingInspired:
    name = "keating"

    def __init__(self, seed=None, unpredictability=None, model=None):
        self.rng = random.Random(seed)
        self.m = model or _model()
        self.u = self.m["assumptions"]["unpredictability"] if unpredictability is None else unpredictability

    def act(self, obs) -> Action:
        street = STREETS[obs.street]
        raises = sum(1 for st, _, a in obs.history if st == obs.street and a.kind == RAISE)
        n_in = sum(obs.in_hand)
        facing = obs.to_call > 0
        key = situation_key(street, raises, facing, n_in)
        cell = self.m["actions"].get(key)
        probs = [cell["probs"][a] for a in ACTIONS] if cell else [0.3, 0.5, 0.2]
        if not facing:
            probs[0] = 0.0                       # never fold when checking is free
        if RAISE not in obs.legal:
            probs[1] += probs[2]
            probs[2] = 0.0
        z = sum(probs) or 1.0
        probs = [p / z for p in probs]

        if obs.street == 0:
            strength = preflop_pct(obs.hole)
        else:
            eq = postflop_equity(obs.hole, obs.board, 1)
            strength = _eq_quantile(obs.street, eq)

        if self.rng.random() < self.u:
            r, acc, choice = self.rng.random(), 0.0, 1
            for i, p in enumerate(probs):
                acc += p
                if r <= acc:
                    choice = i
                    break
        else:
            if probs[2] > 0 and strength >= 1.0 - probs[2]:
                choice = 2
            elif strength < probs[0]:
                choice = 0
            else:
                choice = 1

        if choice == 0:
            return Action(FOLD) if FOLD in obs.legal else Action(CHECK)
        if choice == 1:
            return Action(CHECK) if CHECK in obs.legal else Action(CALL)
        return self._aggressive(obs, street, raises)

    def _aggressive(self, obs, street, raises) -> Action:
        eff_bb = (obs.my_stack + obs.my_bet) / obs.bb
        fam = "pre" if street == "preflop" else "post"
        sp = self.m["sizes"][fam]["probs"]
        r, acc, b = self.rng.random(), 0.0, 1
        for i, name in enumerate(SIZE_BINS):
            acc += sp[name]
            if r <= acc:
                b = i
                break
        jitter = self.rng.uniform(0.9, 1.1)
        if b == 4 or (street == "preflop" and eff_bb <= 12):
            to = obs.max_raise_to
        elif street == "preflop":
            high = obs.my_bet + obs.to_call
            to = (PRE_UNOPENED_BB[b] * obs.bb if raises == 0 else PRE_MULTIPLE[b] * high) * jitter
        else:
            pot_after_call = obs.pot + obs.to_call
            to = obs.my_bet + obs.to_call + POST_FRACTION[b] * pot_after_call * jitter
        to = int(max(obs.min_raise_to, min(obs.max_raise_to, to)))
        return Action(RAISE, to)
