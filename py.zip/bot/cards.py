"""
Pure-Python hand evaluation and hand-strength features. No C extensions, so it runs
in any sandbox, and every function here costs tens of microseconds, well inside a
1 ms decision budget.

Cards are ints 0..51: rank = c // 4 (0 = deuce .. 12 = ace), suit = c % 4.
"""
from __future__ import annotations

from typing import Sequence, Tuple

RANKS = "23456789TJQKA"
SUITS = "cdhs"
HIGH, PAIR, TWO_PAIR, TRIPS, STRAIGHT, FLUSH, FULL_HOUSE, QUADS, STRAIGHT_FLUSH = range(9)


def parse(s: str) -> int:
    return RANKS.index(s[0]) * 4 + SUITS.index(s[1])


def _straight_high(mask: int) -> int:
    """Highest straight in a 13-bit rank mask, or -1. Handles the wheel."""
    if mask & 0x100F == 0x100F:          # A-2-3-4-5 candidate
        wheel = True
    else:
        wheel = False
    for hi in range(12, 3, -1):
        m = 0x1F << (hi - 4)
        if mask & m == m:
            return hi
    return 3 if wheel else -1


def evaluate(cards: Sequence[int]) -> int:
    """Strength of the best 5-card hand among 5-7 cards. Higher is better."""
    cnt = [0] * 13
    suit_cnt = [0, 0, 0, 0]
    for c in cards:
        cnt[c >> 2] += 1
        suit_cnt[c & 3] += 1
    mask = 0
    for r in range(13):
        if cnt[r]:
            mask |= 1 << r
    fs = -1
    for s in range(4):
        if suit_cnt[s] >= 5:
            fs = s
    if fs >= 0:
        fmask = 0
        for c in cards:
            if c & 3 == fs:
                fmask |= 1 << (c >> 2)
        sh = _straight_high(fmask)
        if sh >= 0:
            return (STRAIGHT_FLUSH << 20) | sh
    quads = trips = -1
    pairs = []
    for r in range(12, -1, -1):
        k = cnt[r]
        if k == 4:
            quads = r
        elif k == 3:
            if trips < 0:
                trips = r
            else:
                pairs.append(r)   # second set counts as a pair for full houses
        elif k == 2:
            pairs.append(r)
    if quads >= 0:
        kick = max(r for r in range(13) if cnt[r] and r != quads)
        return (QUADS << 20) | (quads << 4) | kick
    if trips >= 0 and pairs:
        return (FULL_HOUSE << 20) | (trips << 4) | max(pairs)
    if fs >= 0:
        top = sorted((c >> 2 for c in cards if c & 3 == fs), reverse=True)[:5]
        v = 0
        for r in top:
            v = (v << 4) | r
        return (FLUSH << 20) | v
    sh = _straight_high(mask)
    if sh >= 0:
        return (STRAIGHT << 20) | sh
    singles = [r for r in range(12, -1, -1) if cnt[r] == 1]
    if trips >= 0:
        return (TRIPS << 20) | (trips << 8) | (singles[0] << 4) | singles[1]
    if len(pairs) >= 2:
        p1, p2 = pairs[0], pairs[1]
        rest = [r for r in range(12, -1, -1) if cnt[r] and r != p1 and r != p2]
        return (TWO_PAIR << 20) | (p1 << 8) | (p2 << 4) | rest[0]
    if pairs:
        p = pairs[0]
        v = p
        for r in singles[:3]:
            v = (v << 4) | r
        return (PAIR << 20) | v
    v = 0
    for r in singles[:5]:
        v = (v << 4) | r
    return v


def category(score: int) -> int:
    return score >> 20


# ---------------------------------------------------------------- preflop
def preflop_class(hole: Sequence[int]) -> str:
    a, b = hole
    ra, rb = a >> 2, b >> 2
    if ra < rb:
        ra, rb = rb, ra
    if ra == rb:
        return RANKS[ra] * 2
    return RANKS[ra] + RANKS[rb] + ("s" if (a & 3) == (b & 3) else "o")


# ---------------------------------------------------------------- postflop features
def _draw_code(hole, board) -> int:
    """0 none, 1 gutshot, 2 open-ender, 3 flush draw, 4 flush draw + straight draw."""
    cards = list(hole) + list(board)
    fd = False
    for s in range(4):
        n_all = sum(1 for c in cards if c & 3 == s)
        n_hole = sum(1 for c in hole if c & 3 == s)
        if n_all == 4 and n_hole >= 1:
            fd = True
    mask = 0
    for c in cards:
        mask |= 1 << (c >> 2)
    bmask = 0
    for c in board:
        bmask |= 1 << (c >> 2)
    outs = 0
    for r in range(13):
        if mask & (1 << r):
            continue
        if _straight_high(mask | (1 << r)) >= 0 and _straight_high(bmask | (1 << r)) < 0:
            outs += 1
    sd = 2 if outs >= 2 else 1 if outs == 1 else 0
    if fd:
        return 4 if sd else 3
    return sd


def features(hole: Sequence[int], board: Sequence[int]) -> str:
    """Compact description of how our hand relates to the board, used as a key into
    precomputed equity tables. Examples: 'P:top:k2:d0', 'S:set', 'H:o2:d3', 'B'."""
    score = evaluate(list(hole) + list(board))
    cat = score >> 20
    bscore = evaluate(board) if len(board) >= 5 else _partial_board_score(board)
    bcat = bscore >> 20
    branks = sorted({c >> 2 for c in board}, reverse=True)
    h1, h2 = hole[0] >> 2, hole[1] >> 2
    hi, lo = max(h1, h2), min(h1, h2)
    draw = _draw_code(hole, board) if len(board) < 5 else 0

    if cat <= bcat and len(board) >= 5 and score <= _board_plays(board, hole):
        return "B"
    if cat == HIGH:
        overs = sum(1 for r in (h1, h2) if r > branks[0])
        return f"H:o{overs}:d{draw}"
    if cat in (PAIR, TWO_PAIR):
        # the pair(s) we actually make with our hole cards
        if h1 == h2 and h1 not in branks:
            above = sum(1 for r in branks if r > h1)
            pos = "over" if above == 0 else f"pp{min(above, 2)}"
            if cat == TWO_PAIR:          # pocket pair on a paired board
                return f"P:{pos}:pb:d{draw}"
            return f"P:{pos}:d{draw}"
        mine = [r for r in (h1, h2) if r in branks]
        if cat == TWO_PAIR and len(set(mine)) == 2:
            top_two = sorted(mine, reverse=True) == branks[:2]
            return f"T:{'top' if top_two else 'low'}:d{draw}"
        if not mine:
            return f"B:d{draw}"          # board pair, we have nothing
        r = max(mine)
        above = sum(1 for b in branks if b > r)
        kicker = lo if r == hi else hi
        if above == 0:
            k = 2 if kicker >= 10 else 1 if kicker >= 7 else 0
            pos = f"top:k{k}"
        else:
            pos = "mid" if above == 1 else "bot"
        paired_board = bcat >= PAIR
        return f"P:{pos}:{'pb' if paired_board else 'ub'}:d{draw}"
    if cat == TRIPS:
        if h1 == h2:
            return "S:set"
        k = 1 if (hi >= 10 and hi not in branks) or (lo >= 10 and lo not in branks) else 0
        return f"S:trips:k{k}"
    if cat == STRAIGHT:
        used = sum(1 for r in (h1, h2) if r not in branks)
        return f"ST:{min(used, 2)}:{'fb' if _flushy(board) else 'nf'}"
    if cat == FLUSH:
        fsuit = max(range(4), key=lambda s: sum(1 for c in list(hole) + list(board) if c & 3 == s))
        mine = [c >> 2 for c in hole if c & 3 == fsuit]
        top = max(mine) if mine else -1
        tier = 2 if top >= 11 else 1 if top >= 8 else 0
        return f"FL:{len(mine)}:t{tier}"
    if cat == FULL_HOUSE:
        return "FH:b" if bcat >= TRIPS else "FH"
    return "Q+"


def _flushy(board) -> bool:
    sc = [0, 0, 0, 0]
    for c in board:
        sc[c & 3] += 1
    return max(sc) >= 3


def _partial_board_score(board) -> int:
    cnt = {}
    for c in board:
        cnt[c >> 2] = cnt.get(c >> 2, 0) + 1
    m = max(cnt.values())
    if m >= 3:
        return TRIPS << 20
    if m == 2:
        return (TWO_PAIR << 20) if sum(1 for v in cnt.values() if v == 2) >= 2 else (PAIR << 20)
    return 0


def _board_plays(board, hole) -> int:
    return evaluate(board)
