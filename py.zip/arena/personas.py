"""
Practice opponents with mixed, shifting personalities.

Every Player draws its own personality when it sits down: how many hands it opens, how often it
bets its good hands instead of slow-playing them, how light it calls, and how much it bluffs. The
ranges are deliberately moderate, so nobody bluffs every hand or calls everything. On top of that:

  mood     each hand gets a small random lean (looser and braver, or tighter and more careful)
  tilt     after losing a big pot the player plays a little looser for a few hands
  gears    every 20-45 hands the personality drifts part of the way toward a fresh draw
  mixing   strong hands are sometimes slow-played, medium hands are sometimes raised, close calls
           sometimes go the other way, and bet sizes vary, so one action never gives the hand away

The same seed always gives the same player, so a game can be replayed exactly.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, fields, replace

from bot.tables import postflop_equity, preflop_pct

from .bluffing import BluffBrain, BluffStyle
from .engine import CALL, CHECK, FOLD, RAISE, Action

# A balanced bluffing profile; each player scales it by its own bluff level (0.5x to 1.4x).
BASE_BLUFFS = BluffStyle(steal=0.30, light_3bet=0.06, cbet_air=0.55, semi_bet=0.60, semi_raise=0.20,
                         barrel=0.35, river_bluff=0.25)

NAMES = ["Ava", "Ben", "Cleo", "Dev", "Eli", "Fay", "Gus", "Ivy", "Jon", "Kai", "Lena", "Max", "Nia",
         "Omar", "Pia", "Rex", "Sol", "Tess", "Uma", "Vic", "Wes", "Zoe", "Ari", "Bea", "Cy", "Dana"]


@dataclass
class Personality:
    open_cut: float      # preflop percentile needed to open an unraised pot (0.62 = top 38%)
    limp: float          # chance to limp a hand just below the open range instead of folding
    call_cut: float      # percentile needed to call a raise
    three_cut: float     # percentile needed to 3-bet for value
    push_cut: float      # percentile needed to shove when short-stacked
    aggression: float    # chance to bet/raise a strong hand instead of checking or calling
    value_eq: float      # equity at which a hand is bet for value
    margin: float        # extra equity wanted over pot odds before calling (negative = calls light)
    hero_call: float     # chance to call anyway when a little short of the odds
    bluff: float         # scale on BASE_BLUFFS

    @staticmethod
    def draw(rng: random.Random) -> "Personality":
        return Personality(
            open_cut=rng.uniform(0.62, 0.82), limp=rng.uniform(0.0, 0.35),
            call_cut=rng.uniform(0.78, 0.90), three_cut=rng.uniform(0.91, 0.96),
            push_cut=rng.uniform(0.55, 0.75), aggression=rng.uniform(0.35, 0.85),
            value_eq=rng.uniform(0.58, 0.70), margin=rng.uniform(-0.04, 0.06),
            hero_call=rng.uniform(0.0, 0.15), bluff=rng.uniform(0.5, 1.4))

    def blend(self, other: "Personality", w: float) -> "Personality":
        return Personality(**{f.name: (1 - w) * getattr(self, f.name) + w * getattr(other, f.name)
                              for f in fields(self)})

    def describe(self) -> str:
        loose = "loose" if self.open_cut < 0.69 else "tight" if self.open_cut > 0.76 else "medium-range"
        aggr = "aggressive" if self.aggression > 0.68 else "passive" if self.aggression < 0.5 else "balanced"
        bl = "bluffs often" if self.bluff > 1.15 else "rarely bluffs" if self.bluff < 0.75 else "bluffs sometimes"
        calls = "calls light" if self.margin < 0.0 else "folds to pressure" if self.margin > 0.04 else ""
        return ", ".join(x for x in (loose, aggr, bl, calls) if x)


def _passive(obs):
    return Action(CHECK) if CHECK in obs.legal else Action(CALL)


def _fold(obs):
    return Action(CHECK) if CHECK in obs.legal else Action(FOLD)


def _raise_to(obs, amount):
    if RAISE not in obs.legal:
        return _passive(obs)
    return Action(RAISE, max(obs.min_raise_to, min(obs.max_raise_to, int(amount))))


def _pot_raise(obs, frac):
    return _raise_to(obs, obs.my_bet + obs.to_call + frac * (obs.pot + obs.to_call))


class Player:
    name = "player"

    def __init__(self, seed=None):
        self.rng = random.Random(seed)
        self.base = Personality.draw(self.rng)
        self.brain = BluffBrain(BASE_BLUFFS, random.Random(self.rng.randrange(1 << 30)))
        self.next_gear = self.rng.randint(20, 45)
        self.hand = -1
        self.tilt = 0
        self.last_start = None
        self.p = self.base

    # ------------------------------------------------------------------ per-hand state
    def _new_hand(self, obs):
        self.hand = obs.hand_num
        if obs.hand_num >= self.next_gear:                     # change gears
            self.base = self.base.blend(Personality.draw(self.rng), 0.35)
            self.next_gear = obs.hand_num + self.rng.randint(20, 45)
        start = obs.starting_stacks[obs.seat]
        if self.last_start and start < 0.7 * self.last_start:  # just lost a big pot
            self.tilt = self.rng.randint(2, 5)
        self.last_start = start
        mood = max(-1.5, min(1.5, self.rng.gauss(0.0, 0.6)))
        if self.tilt:
            mood += 0.8
            self.tilt -= 1
        b = self.base
        self.p = replace(
            b, open_cut=min(0.9, max(0.5, b.open_cut - 0.04 * mood)),
            aggression=min(0.92, max(0.25, b.aggression + 0.08 * mood)),
            margin=b.margin - 0.02 * mood, bluff=max(0.3, b.bluff * (1 + 0.25 * mood)))
        k = self.p.bluff
        self.brain.s = BluffStyle(**{f.name: min(0.8, getattr(BASE_BLUFFS, f.name) * k)
                                     for f in fields(BluffStyle) if f.name != "multiway"},
                                  multiway=BASE_BLUFFS.multiway)

    def describe(self) -> str:
        return self.base.describe()

    # ------------------------------------------------------------------ decisions
    def act(self, obs):
        if obs.hand_num != self.hand:
            self._new_hand(obs)
        normal = self._preflop(obs) if obs.street == 0 else self._postflop(obs)
        return self.brain.maybe_bluff(obs, normal)

    def _preflop(self, obs):
        p, rng, bb = self.p, self.rng, obs.bb
        pct = preflop_pct(obs.hole)
        stack = obs.my_stack + obs.my_bet
        stack_bb = stack / bb
        raises = [a for st, _, a in obs.history if st == 0 and a.kind == RAISE]
        late = len(obs.to_act_after) <= 2
        short = max(0, 8 - obs.players_left)                    # fewer players: wider ranges
        if stack_bb < 12:
            cut = p.push_cut - 0.03 * short - (0.05 if late and not raises else 0.0) + (0.12 if raises else 0.0)
            return _raise_to(obs, obs.max_raise_to) if pct >= cut else _fold(obs)
        if not raises:
            cut = p.open_cut - 0.05 * short - (0.07 if late else 0.0) + (0.04 if len(obs.to_act_after) >= 5 else 0.0)
            if pct >= cut:
                return _raise_to(obs, obs.my_bet + obs.to_call + rng.choice((2.0, 2.2, 2.5, 3.0)) * bb)
            if pct >= cut - 0.15 and rng.random() < p.limp:
                return _passive(obs)
            return _fold(obs)
        tc = obs.to_call
        three_cut, call_cut = p.three_cut - 0.02 * short, p.call_cut - 0.04 * short
        if pct >= three_cut and (rng.random() < 0.55 + 0.4 * p.aggression or pct >= 0.985):
            if tc >= 0.4 * stack:
                return _raise_to(obs, obs.max_raise_to)
            return _raise_to(obs, rng.choice((2.7, 3.0, 3.3)) * (obs.my_bet + tc))
        if tc >= 0.4 * stack:                                   # facing a shove or near-shove
            return _passive(obs) if pct >= three_cut - 0.04 else _fold(obs)
        if pct >= call_cut - (0.04 if len(raises) == 1 and obs.seat == obs.button else 0.0) \
                and tc <= (0.12 + 0.1 * (1 - call_cut)) * stack:
            return _passive(obs)
        return _fold(obs)

    def _postflop(self, obs):
        p, rng = self.p, self.rng
        n = max(1, sum(obs.in_hand) - 1)
        eq = postflop_equity(obs.hole, obs.board, min(n, 3))
        tc = obs.to_call
        if tc == 0:
            if eq >= p.value_eq + 0.03 * (n - 1):
                if rng.random() < min(0.95, p.aggression + 0.15):
                    frac = rng.choice((0.33, 0.5, 0.66, 0.75) if p.aggression < 0.6 else (0.5, 0.66, 0.75, 1.0))
                    return _pot_raise(obs, frac)
                return Action(CHECK)                            # slow-play
            if eq >= p.value_eq - 0.1 and rng.random() < 0.25 * p.aggression:
                return _pot_raise(obs, rng.choice((0.33, 0.5)))  # thin bet / protection
            return Action(CHECK)
        b = tc / max(1, obs.pot - tc)
        eq_adj = eq ** (1.0 + 0.8 * min(b, 2.0))                 # bigger bets mean stronger ranges
        odds = tc / (obs.pot + tc)
        if eq_adj >= 0.78 and RAISE in obs.legal and rng.random() < p.aggression:
            return _raise_to(obs, rng.choice((2.5, 3.0)) * (obs.my_bet + tc))
        if eq_adj >= odds + p.margin:
            return _passive(obs)
        if eq_adj >= odds - 0.08 and rng.random() < p.hero_call:
            return _passive(obs)
        return _fold(obs)
