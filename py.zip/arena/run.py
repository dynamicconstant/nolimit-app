"""Run thousands of 8-bot sit-and-gos and score a hero bot.

    python -m arena.run --tables 2000                          # nolimit vs a mixed field
    python -m arena.run --hero tag --tables 2000               # baseline for comparison
    python -m arena.run --field pusher maniac station --tables 1000
    python -m arena.run --payouts 7 6 5 4 3 2 1 0              # try a different point table

Each table: the hero in a random seat, the other 7 seats drawn from the field. The same
seeds are used for every hero, so heroes are compared on identical deals and seatings.
"""
from __future__ import annotations

import argparse
import os
import random
import statistics
import sys
from multiprocessing import Pool

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from arena.engine import DEFAULT_PAYOUTS, DecisionStats, Table, TableConfig  # noqa: E402
from arena.sparring import HELD_OUT, SPARRING  # noqa: E402
from bot.agent import NoLimitAgent  # noqa: E402
from bot.agent_baseline import BaselineAgent  # noqa: E402
from keating.opponent import KeatingInspired  # noqa: E402

BOTS = dict(SPARRING, **HELD_OUT, nolimit=NoLimitAgent, keating=KeatingInspired)
BOTS["nolimit-baseline"] = BaselineAgent
DEFAULT_FIELD = ["tag", "tag", "pusher", "nit", "station", "maniac", "random"]


def run_chunk(args):
    hero, field, tables, seed, payouts, time_limit, enforce = args
    cfg = TableConfig(payouts=tuple(payouts), time_limit=time_limit, enforce_time=enforce)
    points, places = [], []
    hero_stats = DecisionStats()
    for t in range(tables):
        rng = random.Random(seed * 100_003 + t)
        names = [rng.choice(field) for _ in range(cfg.seats - 1)]
        hero_seat = rng.randrange(cfg.seats)
        names.insert(hero_seat, hero)
        bots = [BOTS[nm](rng.randrange(1 << 30)) for nm in names]   # fresh instances per table
        stats = [DecisionStats() for _ in range(cfg.seats)]
        table = Table(bots, cfg, random.Random(rng.randrange(1 << 30)), stats)
        pts = table.play()
        points.append(pts[hero_seat])
        places.append(table.finish.get(hero_seat, 0))   # 0 = survived to the hand cap / won
        hs = stats[hero_seat]
        hero_stats.count += hs.count
        hero_stats.total += hs.total
        hero_stats.worst = max(hero_stats.worst, hs.worst)
        hero_stats.timeouts += hs.timeouts
        hero_stats.errors += hs.errors
        hero_stats.illegal += hs.illegal
        hero_stats.samples += hs.samples[:2000]
    return points, places, hero_stats


def evaluate(hero, field, tables, seed=0, workers=1, payouts=DEFAULT_PAYOUTS, time_limit=0.001, enforce=True):
    per = max(1, tables // workers)
    jobs = [(hero, field, per, seed + i, payouts, time_limit, enforce) for i in range(workers)]
    if workers == 1:
        results = [run_chunk(jobs[0])]
    else:
        with Pool(workers) as pool:
            results = pool.map(run_chunk, jobs)
    points = [p for r in results for p in r[0]]
    places = [p for r in results for p in r[1]]
    st = DecisionStats()
    for r in results:
        s = r[2]
        st.count += s.count; st.total += s.total; st.worst = max(st.worst, s.worst)
        st.timeouts += s.timeouts; st.errors += s.errors; st.illegal += s.illegal
        st.samples += s.samples
    return points, places, st


def report(hero, points, places, st, payouts):
    n = len(points)
    mean = statistics.fmean(points)
    ci = 1.96 * statistics.pstdev(points) / n ** 0.5
    fair = sum(payouts) / len(payouts)
    samples = sorted(st.samples)
    p99 = samples[int(0.99 * (len(samples) - 1))] if samples else 0
    wins = sum(1 for p in points if p >= payouts[0] - 1e-9)
    print(f"{hero}: {mean:.2f} points/table (±{ci:.2f}, fair share {fair:.2f}) over {n} tables"
          f" -> {mean / fair:.2f}x fair")
    print(f"  outright wins {wins / n:.1%}   in the points {sum(1 for p in points if p > 0) / n:.1%}")
    print(f"  decision time: mean {st.total / max(1, st.count) * 1e6:.0f}µs  p99 {p99 * 1e6:.0f}µs"
          f"  worst {st.worst * 1e6:.0f}µs  timeouts {st.timeouts}  errors {st.errors}  illegal {st.illegal}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hero", default="nolimit", choices=list(BOTS))
    ap.add_argument("--field", nargs="+", default=DEFAULT_FIELD, choices=list(BOTS))
    ap.add_argument("--tables", type=int, default=1000)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--workers", type=int, default=os.cpu_count() or 1)
    ap.add_argument("--payouts", type=float, nargs="+", default=DEFAULT_PAYOUTS)
    ap.add_argument("--time-limit-ms", type=float, default=1.0)
    ap.add_argument("--no-enforce-time", action="store_true")
    a = ap.parse_args()
    pts, places, st = evaluate(a.hero, a.field, a.tables, a.seed, a.workers, a.payouts,
                               a.time_limit_ms / 1000, not a.no_enforce_time)
    report(a.hero, pts, places, st, a.payouts)


if __name__ == "__main__":
    main()
