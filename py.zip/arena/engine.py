"""
Practice arena that mirrors the published No Limit regional format:

  * 8-bot sit-and-go, 2,000 starting chips, blinds 10/20 rising every 25 hands
  * a table ends when one bot has every chip, or after 200 hands
  * points by finishing position; survivors at hand 200 split remaining points by ICM
  * every decision must return within the time limit (1 ms), otherwise the bot
    folds (or checks when checking is free); exceptions are treated the same way
  * a fresh bot instance per table (official rules: state resets at each table)

The real engine, Agent interface, payout table and blind schedule come with the
starter kit on event day. Everything here is configurable so you can match them.

Cards are ints 0..51: rank = c // 4 (0 = deuce .. 12 = ace), suit = c % 4.
"""
from __future__ import annotations

import random
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence, Tuple

try:                                   # fast C evaluator if installed...
    import eval7
except ImportError:                    # ...otherwise the bot's own pure-Python one (same ordering)
    eval7 = None

from .icm import icm_equity

FOLD, CHECK, CALL, RAISE = "F", "K", "C", "R"
STREETS = ("preflop", "flop", "turn", "river")
RANKS, SUITS = "23456789TJQKA", "cdhs"
E7 = [eval7.Card(RANKS[c // 4] + SUITS[c % 4]) for c in range(52)] if eval7 else None


def _rank7(cards7):
    if eval7:
        return eval7.evaluate([E7[c] for c in cards7])
    from bot.cards import evaluate
    return evaluate(cards7)


def card_str(c: int) -> str:
    return RANKS[c // 4] + SUITS[c % 4]


# Guesses until the starter kit is released; override via TableConfig.
DEFAULT_BLINDS = [(10, 20), (15, 30), (25, 50), (50, 100), (75, 150), (100, 200), (150, 300), (200, 400)]
DEFAULT_PAYOUTS = [50, 30, 20, 0, 0, 0, 0, 0]


@dataclass(frozen=True)
class Action:
    kind: str
    amount: int = 0  # RAISE: total committed this street after raising ("raise to")

    def __str__(self):
        return f"{self.kind}{self.amount}" if self.kind == RAISE else self.kind


@dataclass
class TableConfig:
    seats: int = 8
    starting_stack: int = 2000
    blinds: Sequence[Tuple[int, int]] = tuple(DEFAULT_BLINDS)
    hands_per_level: int = 25
    max_hands: int = 200
    payouts: Sequence[float] = tuple(DEFAULT_PAYOUTS)
    time_limit: float = 0.001        # seconds per decision
    enforce_time: bool = True


@dataclass
class Observation:
    seat: int
    hand_num: int
    hole: Tuple[int, int]
    board: Tuple[int, ...]
    street: int
    pot: int                  # all chips committed this hand
    to_call: int
    min_raise_to: int
    max_raise_to: int
    legal: frozenset
    my_bet: int               # committed this street
    stacks: Tuple[int, ...]   # chips behind for every seat (0 = busted or all-in)
    bets: Tuple[int, ...]     # street commitments for every seat
    in_hand: Tuple[bool, ...] # dealt in and not folded
    all_in: Tuple[bool, ...]
    button: int
    sb: int
    bb: int
    players_left: int         # seats with chips (still in the tournament)
    to_act_after: Tuple[int, ...]  # seats still to act behind us this round (not folded/all-in)
    history: Tuple[Tuple[int, int, Action], ...]  # (street, seat, action) this hand
    payouts: Tuple[float, ...]
    starting_stacks: Tuple[int, ...]  # stacks at the start of this hand

    @property
    def my_stack(self) -> int:
        return self.stacks[self.seat]


@dataclass
class HandSummary:
    hand_num: int
    board: Tuple[int, ...]
    shown: Dict[int, Tuple[int, int]]   # seat -> hole cards revealed at showdown
    history: Tuple[Tuple[int, int, Action], ...]
    deltas: Tuple[int, ...]
    starting_stacks: Tuple[int, ...]


@dataclass
class DecisionStats:
    count: int = 0
    total: float = 0.0
    worst: float = 0.0
    timeouts: int = 0
    errors: int = 0
    illegal: int = 0
    samples: List[float] = field(default_factory=list)

    def add(self, dt: float):
        self.count += 1
        self.total += dt
        self.worst = max(self.worst, dt)
        if len(self.samples) < 200_000:
            self.samples.append(dt)


class Table:
    def __init__(self, bots: List, cfg: TableConfig, rng: random.Random, stats: Optional[List[DecisionStats]] = None):
        self.bots, self.cfg, self.rng = bots, cfg, rng
        n = cfg.seats
        self.stacks = [cfg.starting_stack] * n
        self.button = rng.randrange(n)
        self.finish: Dict[int, int] = {}       # seat -> place (1 = winner)
        self.stats = stats or [DecisionStats() for _ in range(n)]
        self.hand_num = 0
        for s, b in enumerate(bots):
            if hasattr(b, "new_table"):
                b.new_table(s, n)

    # ------------------------------------------------------------------ tournament
    def alive(self) -> List[int]:
        return [s for s in range(self.cfg.seats) if self.stacks[s] > 0]

    def blinds(self) -> Tuple[int, int]:
        lvl = min(self.hand_num // self.cfg.hands_per_level, len(self.cfg.blinds) - 1)
        return self.cfg.blinds[lvl]

    def next_alive(self, seat: int) -> int:
        n = self.cfg.seats
        for k in range(1, n + 1):
            s = (seat + k) % n
            if self.stacks[s] > 0:
                return s
        return seat

    def play(self) -> List[float]:
        """Run the table to completion. Returns points per seat."""
        for _ in self.run():
            raise RuntimeError("a human seat needs Table.run(), not play()")
        return self.points()

    def run(self):
        """Generator form: yields an Observation whenever a seat marked `human` must act;
        send the Action back in. Identical play to play() for bot-only tables."""
        while len(self.alive()) > 1 and self.hand_num < self.cfg.max_hands:
            if self.hand_num:
                self.button = self.next_alive(self.button)
            before = list(self.stacks)
            yield from self.play_hand()
            busted = [s for s in range(self.cfg.seats) if before[s] > 0 and self.stacks[s] == 0]
            # Busting in the same hand: bigger starting stack finishes higher.
            busted.sort(key=lambda s: before[s])
            place = len(self.alive()) + len(busted)
            for s in busted:
                self.finish[s] = place
                place -= 1
            self.hand_num += 1

    def points(self) -> List[float]:
        points = [0.0] * self.cfg.seats
        pay = list(self.cfg.payouts) + [0] * self.cfg.seats
        for s, p in self.finish.items():
            points[s] = pay[p - 1]
        alive = self.alive()
        if len(alive) == 1:
            points[alive[0]] = pay[0]
        elif alive:
            eq = icm_equity([self.stacks[s] for s in alive], pay[: len(alive)])
            for s, e in zip(alive, eq):
                points[s] = e
        return points

    # ------------------------------------------------------------------ one hand
    def play_hand(self):
        """Generator: plays one hand; yields observations for human seats (see run())."""
        cfg, n = self.cfg, self.cfg.seats
        sb_amt, bb_amt = self.blinds()
        start = list(self.stacks)
        players = self.alive()
        deck = list(range(52))
        self.rng.shuffle(deck)
        if getattr(self, "forced_deck", None):      # tests: deal a fixed deck (popped from the end)
            deck = list(self.forced_deck)
        hole = {s: (deck.pop(), deck.pop()) for s in players}
        full_board = [deck.pop() for _ in range(5)]

        stacks = self.stacks
        bet = [0] * n
        total = [0] * n
        in_hand = [s in hole for s in range(n)]
        allin = [False] * n
        history: List[Tuple[int, int, Action]] = []

        def post(s, amt):
            amt = min(amt, stacks[s])
            stacks[s] -= amt
            bet[s] += amt
            total[s] += amt
            if stacks[s] == 0:
                allin[s] = True

        if len(players) == 2:
            sb_seat = self.button
            bb_seat = self.next_alive(sb_seat)
        else:
            sb_seat = self.next_alive(self.button)
            bb_seat = self.next_alive(sb_seat)
        post(sb_seat, sb_amt)
        post(bb_seat, bb_amt)
        listener = getattr(self, "listener", None)   # optional UI hook; never affects play
        if listener:
            listener.on_deal(self, hole, sb_seat, bb_seat, sb_amt, bb_amt, start, list(stacks), list(bet))

        def order_from(first):
            out, s = [], first
            for _ in range(n):
                if in_hand[s]:
                    out.append(s)
                s = (s + 1) % n
            return out

        street = 0
        board: List[int] = []
        while True:
            # ---------------------------------------------------------- betting round
            first = self.next_alive(bb_seat) if street == 0 else self.next_alive(self.button)
            if street == 0 and len(players) == 2:
                first = sb_seat
            seq = order_from(first)
            last_raise = bb_amt
            high = max(bet)
            acted = {s: False for s in seq}
            idx = 0
            while True:
                actors = [s for s in seq if in_hand[s] and not allin[s]]
                live = [s for s in seq if in_hand[s]]
                if len(live) <= 1:
                    break
                pending = [s for s in actors if not acted[s] or bet[s] < high]
                if not pending or (len(actors) == 1 and bet[actors[0]] >= high):
                    break
                s = seq[idx % len(seq)]
                idx += 1
                if not in_hand[s] or allin[s] or (acted[s] and bet[s] >= high):
                    continue
                to_call = min(high - bet[s], stacks[s])
                legal = {FOLD, CALL} if high > bet[s] else {CHECK}
                max_to = bet[s] + stacks[s]
                others_can_call = any(in_hand[o] and not allin[o] and o != s for o in seq)
                min_to = min(high + last_raise, max_to)
                if max_to > high and others_can_call:
                    legal.add(RAISE)
                after = []
                for k in range(1, len(seq)):
                    o = seq[(seq.index(s) + k) % len(seq)]
                    if in_hand[o] and not allin[o] and o != s:
                        after.append(o)
                obs = Observation(
                    seat=s, hand_num=self.hand_num, hole=hole[s], board=tuple(board), street=street,
                    pot=sum(total), to_call=to_call, min_raise_to=min_to, max_raise_to=max_to,
                    legal=frozenset(legal), my_bet=bet[s], stacks=tuple(stacks), bets=tuple(bet),
                    in_hand=tuple(in_hand), all_in=tuple(allin), button=self.button, sb=sb_amt, bb=bb_amt,
                    players_left=len(players), to_act_after=tuple(after), history=tuple(history),
                    payouts=tuple(cfg.payouts), starting_stacks=tuple(start),
                )
                if getattr(self.bots[s], "human", False):
                    action = yield obs
                else:
                    action = self._ask(s, obs)
                action = self._sanitize(s, action, obs)
                history.append((street, s, action))
                acted[s] = True
                if action.kind == FOLD:
                    in_hand[s] = False
                elif action.kind == CALL:
                    post(s, to_call)
                elif action.kind == RAISE:
                    raise_by = action.amount - high
                    if raise_by >= last_raise:
                        last_raise = raise_by
                    post(s, action.amount - bet[s])
                    high = max(high, bet[s])
                    for o in seq:
                        if o != s:
                            acted[o] = False
                if listener:
                    listener.on_action(self, street, s, action, list(stacks), list(bet), sum(total), list(in_hand))

            live = [s for s in range(n) if in_hand[s]]
            if len(live) == 1:
                break
            can_act = [s for s in live if not allin[s]]
            if street == 3 or len(can_act) <= 1:
                if listener and street < 3:               # all-in: run out the rest of the board
                    listener.on_street(self, 3, list(full_board), sum(total))
                board = full_board[:]
                break
            street += 1
            board = full_board[: (0, 3, 4, 5)[street]]
            bet = [0] * n
            if listener:
                listener.on_street(self, street, list(board), sum(total))

        # ---------------------------------------------------------- settle
        live = [s for s in range(n) if in_hand[s]]
        shown: Dict[int, Tuple[int, int]] = {}
        if len(live) == 1:
            stacks[live[0]] += sum(total)
        else:
            ranks = {s: _rank7([hole[s][0], hole[s][1]] + list(full_board)) for s in live}
            shown = {s: hole[s] for s in live}
            levels = sorted(set(total[s] for s in range(n) if total[s] > 0))
            prev = 0
            for lv in levels:
                pot = sum(min(total[s], lv) - min(total[s], prev) for s in range(n))
                elig = [s for s in live if total[s] >= lv]
                prev = lv
                if pot == 0:
                    continue
                if not elig:  # only folded players reached this level: return it
                    contrib = [s for s in range(n) if total[s] >= lv]
                    stacks[contrib[0]] += pot
                    continue
                best = max(ranks[s] for s in elig)
                winners = [s for s in order_from(self.next_alive(self.button)) if s in elig and ranks[s] == best] \
                    or [s for s in elig if ranks[s] == best]
                share, odd = divmod(pot, len(winners))
                for i, w in enumerate(winners):
                    stacks[w] += share + (1 if i < odd else 0)
        summary = HandSummary(self.hand_num, tuple(board), shown, tuple(history),
                              tuple(stacks[s] - start[s] for s in range(n)), tuple(start))
        if listener:
            listener.on_hand_end(self, summary, list(stacks), dict(hole))
        for b in self.bots:
            if hasattr(b, "hand_over"):
                try:
                    b.hand_over(summary)
                except Exception:
                    pass

    # ------------------------------------------------------------------ bot calls
    def _ask(self, s: int, obs: Observation) -> Optional[Action]:
        st = self.stats[s]
        t0 = time.perf_counter()
        try:
            a = self.bots[s].act(obs)
        except Exception:
            st.errors += 1
            a = None
        dt = time.perf_counter() - t0
        st.add(dt)
        if self.cfg.enforce_time and dt > self.cfg.time_limit:
            st.timeouts += 1
            return None
        return a

    def _sanitize(self, s: int, a: Optional[Action], obs: Observation) -> Action:
        default = Action(CHECK) if CHECK in obs.legal else Action(FOLD)
        if not isinstance(a, Action):
            return default
        if a.kind == CALL and CHECK in obs.legal:
            return Action(CHECK)
        if a.kind not in obs.legal:
            self.stats[s].illegal += 1
            return default
        if a.kind == RAISE:
            amt = max(obs.min_raise_to, min(obs.max_raise_to, int(a.amount)))
            if amt != a.amount:
                self.stats[s].illegal += 1
            return Action(RAISE, amt)
        return a
