"""Sparring partners modeled on what teams typically ship after 60 minutes.
All of them are fast enough to respect the 1 ms limit."""
from __future__ import annotations

import random

from bot.cards import PAIR, TWO_PAIR, category, evaluate
from bot.tables import preflop_pct

from .engine import CALL, CHECK, FOLD, RAISE, Action


def _passive(obs):
    return Action(CHECK) if CHECK in obs.legal else Action(CALL)


def _fold(obs):
    return Action(CHECK) if CHECK in obs.legal else Action(FOLD)


def _raise_to(obs, amount):
    if RAISE not in obs.legal:
        return _passive(obs)
    return Action(RAISE, max(obs.min_raise_to, min(obs.max_raise_to, int(amount))))


def _pot_raise(obs, frac=1.0):
    return _raise_to(obs, obs.my_bet + obs.to_call + frac * (obs.pot + obs.to_call))


def _made(obs) -> int:
    return category(evaluate(list(obs.hole) + list(obs.board)))


class RandomBot:
    name = "random"

    def __init__(self, seed=None):
        self.rng = random.Random(seed)

    def act(self, obs):
        r = self.rng.random()
        if r < 0.25:
            return _fold(obs)
        if r < 0.85:
            return _passive(obs)
        return _pot_raise(obs, self.rng.choice([0.5, 1.0]))


class Station:
    name = "station"

    def __init__(self, seed=None):
        pass

    def act(self, obs):
        return _passive(obs)


class Maniac:
    name = "maniac"

    def __init__(self, seed=None):
        pass

    def act(self, obs):
        return _pot_raise(obs, 1.0)


class Pusher:
    """Shove the top 30% of hands preflop, fold everything else. A classic quick build."""
    name = "pusher"

    def __init__(self, seed=None, top=0.30):
        self.cut = 1 - top

    def act(self, obs):
        if obs.street == 0:
            if preflop_pct(obs.hole) >= self.cut:
                return _raise_to(obs, obs.max_raise_to) if RAISE in obs.legal else _passive(obs)
            return _fold(obs)
        return _passive(obs)


class Nit:
    name = "nit"

    def __init__(self, seed=None):
        pass

    def act(self, obs):
        if obs.street == 0:
            if preflop_pct(obs.hole) >= 0.90:
                return _raise_to(obs, obs.my_bet + obs.to_call + 3 * obs.bb)
            return _fold(obs)
        if _made(obs) >= TWO_PAIR:
            return _pot_raise(obs, 0.75)
        if _made(obs) >= PAIR and obs.to_call <= obs.pot * 0.5:
            return _passive(obs)
        return _fold(obs)


class TAG:
    """A reasonable 60-minute bot: positional-ish preflop, made-hand postflop, some c-bets."""
    name = "tag"

    def __init__(self, seed=None):
        self.rng = random.Random(seed)

    def act(self, obs):
        pct = preflop_pct(obs.hole)
        stack_bb = (obs.my_stack + obs.my_bet) / obs.bb
        if obs.street == 0:
            if stack_bb < 12:
                return _raise_to(obs, obs.max_raise_to) if pct >= 0.75 else _fold(obs)
            raised = any(a.kind == RAISE for st, _, a in obs.history if st == 0)
            if not raised:
                return _raise_to(obs, obs.my_bet + obs.to_call + 2.5 * obs.bb) if pct >= 0.78 else _fold(obs)
            if pct >= 0.95:
                return _pot_raise(obs, 1.0)
            if pct >= 0.88 and obs.to_call <= 0.15 * obs.my_stack:
                return _passive(obs)
            return _fold(obs)
        made = _made(obs)
        if made >= TWO_PAIR:
            return _pot_raise(obs, 0.7)
        if made >= PAIR:
            if obs.to_call == 0:
                return _pot_raise(obs, 0.5) if self.rng.random() < 0.6 else _passive(obs)
            return _passive(obs) if obs.to_call <= 0.6 * obs.pot else _fold(obs)
        if obs.to_call == 0 and self.rng.random() < 0.25:
            return _pot_raise(obs, 0.5)
        return _fold(obs)


SPARRING = {"random": RandomBot, "station": Station, "maniac": Maniac, "pusher": Pusher, "nit": Nit, "tag": TAG}


# ---------------------------------------------------------------- held-out opponents
# Never used in training; they test generalization to loose, unpredictable play.

class LoosePassive:
    """Plays most hands, rarely raises, calls down with any pair or draw."""
    name = "loose-passive"

    def __init__(self, seed=None):
        self.rng = random.Random(seed)

    def act(self, obs):
        if obs.street == 0:
            pct = preflop_pct(obs.hole)
            if pct >= 0.96 and self.rng.random() < 0.5:
                return _pot_raise(obs, 0.75)
            if pct >= 0.25 or obs.to_call <= obs.bb:
                return _passive(obs)
            return _fold(obs)
        made = _made(obs)
        if made >= TWO_PAIR and self.rng.random() < 0.3:
            return _pot_raise(obs, 0.5)
        if made >= PAIR or obs.to_call <= 0.4 * obs.pot:
            return _passive(obs)
        return _fold(obs)


class Erratic:
    """Switches personality (maniac / station / nit / random) every 10-30 hands."""
    name = "erratic"

    def __init__(self, seed=None):
        self.rng = random.Random(seed)
        self.modes = [Maniac(seed), Station(seed), Nit(seed), RandomBot(seed), TAG(seed)]
        self.mode = self.rng.choice(self.modes)
        self.until = self.rng.randint(10, 30)

    def act(self, obs):
        if obs.hand_num >= self.until:
            self.mode = self.rng.choice(self.modes)
            self.until = obs.hand_num + self.rng.randint(10, 30)
        return self.mode.act(obs)


HELD_OUT = {"loose-passive": LoosePassive, "erratic": Erratic}
