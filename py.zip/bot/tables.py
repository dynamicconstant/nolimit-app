"""Loads the precomputed equity tables once and exposes O(1) lookups."""
from __future__ import annotations

import bisect
import json
import os
from functools import lru_cache

from .cards import features, preflop_class

PATH = os.path.join(os.path.dirname(__file__), "data", "tables.json")


@lru_cache(maxsize=1)
def tables() -> dict:
    with open(PATH) as f:
        t = json.load(f)
    t["post"] = {int(k): v for k, v in t["post"].items()}
    return t


def preflop_equity(hole, n_opp: int) -> float:
    return tables()["preflop"][preflop_class(hole)][max(1, min(7, n_opp)) - 1]


def preflop_pct(hole) -> float:
    """Fraction of starting hands this hand beats (1.0 = AA, ~0.0 = 72o)."""
    return tables()["pct"][preflop_class(hole)]


def preflop_vs_top(hole, top_pct: float) -> float:
    """Heads-up equity vs a range of the top `top_pct` % of hands (interpolated)."""
    t = tables()
    xs, ys = t["top_x"], t["preflop_vs"][preflop_class(hole)]
    x = max(xs[0], min(xs[-1], top_pct))
    i = bisect.bisect_left(xs, x)
    if xs[i] == x or i == 0:
        return ys[i]
    x0, x1 = xs[i - 1], xs[i]
    return ys[i - 1] + (ys[i] - ys[i - 1]) * (x - x0) / (x1 - x0)


_FALLBACK = {1: 0.5, 2: 0.33, 3: 0.25}


def postflop_equity(hole, board, n_opp: int) -> float:
    """Equity vs n_opp random hands, from the hand's feature class."""
    street = {3: 1, 4: 2, 5: 3}[len(board)]
    f = features(hole, board)
    row = tables()["post"][street].get(f)
    if row is None:
        # unseen feature: back off to its prefix (e.g. 'P:top:k2:ub:d3' -> 'P:top:k2:ub:d0')
        row = tables()["post"][street].get(f.rsplit(":", 1)[0] + ":d0")
    if row is None:
        return _FALLBACK.get(min(n_opp, 3), 0.2) if n_opp <= 3 else 0.15
    if n_opp <= 3:
        return row[n_opp - 1]
    e2, e3 = row[1], row[2]
    ratio = e3 / e2 if e2 > 0 else 0.5
    return e3 * ratio ** (n_opp - 3)
