"""
Keating-inspired opponent model: conditional action and sizing probabilities.

    python -m keating.model fit [--include-highlights]   # -> keating/model/keating_model.json
    python -m keating.model report                       # measured vs assumed, per cell

Structure (deliberately simple and interpretable, because the measured sample is tiny):

  P(action class | situation)   action class in {fold, passive, aggressive}
  P(size bin | situation)       for aggressive actions

  situation = street x pressure (unopened / facing one raise / facing re-raise on preflop;
              no bet / facing a bet postflop) x heads-up vs multiway (postflop only)

Every cell is a Dirichlet posterior: an ASSUMED loose-aggressive prior (20 pseudo-counts)
plus MEASURED decisions from the validated dataset. Each cell is labeled by how much of it
is measured. Highlight hands are excluded from counts by default, because big-pot
highlights over-represent aggression. Aggregate stats (VPIP/PFR) are sanity checks only.
"""
from __future__ import annotations

import json
import os
import sys
from typing import Dict, List, Optional, Tuple

HERE = os.path.dirname(__file__)
DECISIONS = os.path.join(HERE, "data", "decisions.jsonl")
MODEL_PATH = os.path.join(HERE, "model", "keating_model.json")

ACTIONS = ("fold", "passive", "aggressive")
SIZE_BINS = ("small", "medium", "large", "overbet", "all_in")
PRIOR_STRENGTH = 20.0

# Public aggregates used ONLY as sanity checks (Highroll Poker tracker, player 1475, read 2026-10-29).
SANITY_TARGETS = {
    "source": "https://highrollpoker.com/tracker/players/1475",
    "note": "Hustler Casino Live: VPIP 68%, PFR 30% over 187.5 h; all venues 69% / 30%. Deep-stacked, "
            "~9-handed, straddled cash games; tracker definitions unpublished. Rough targets, not a strategy.",
    "vpip": 0.68,
    "pfr": 0.30,
}

# ---------------------------------------------------------------- ASSUMED prior
# Loose-aggressive archetype. These numbers are assumptions, tuned only so the simulated bot's
# VPIP/PFR land near the public aggregates above. Replace by data as annotation proceeds.
PRIOR_ACTIONS: Dict[str, Tuple[float, float, float]] = {
    "pre:unopened":   (0.32, 0.30, 0.38),
    "pre:raised":     (0.33, 0.50, 0.17),
    "pre:reraised":   (0.45, 0.42, 0.13),
    "flop:nobet:hu":  (0.00, 0.40, 0.60),
    "flop:nobet:mw":  (0.00, 0.50, 0.50),
    "flop:bet:hu":    (0.22, 0.50, 0.28),
    "flop:bet:mw":    (0.30, 0.48, 0.22),
    "turn:nobet:hu":  (0.00, 0.45, 0.55),
    "turn:nobet:mw":  (0.00, 0.55, 0.45),
    "turn:bet:hu":    (0.30, 0.48, 0.22),
    "turn:bet:mw":    (0.38, 0.45, 0.17),
    "river:nobet:hu": (0.00, 0.50, 0.50),
    "river:nobet:mw": (0.00, 0.60, 0.40),
    "river:bet:hu":   (0.38, 0.42, 0.20),
    "river:bet:mw":   (0.45, 0.40, 0.15),
}
PRIOR_SIZES: Dict[str, Tuple[float, ...]] = {
    # preflop bins are raise-to sizes: unopened in big blinds (<2.5, 2.5-3.5, 3.5-5, >=5, all-in),
    # facing a raise as a multiple of the raise faced (<2.5x, 2.5-3.5x, 3.5-5x, >=5x, all-in)
    "pre":  (0.15, 0.40, 0.25, 0.12, 0.08),
    # postflop bins are pot fractions of the increment: <0.4, 0.4-0.8, 0.8-1.3, >=1.3, all-in
    "post": (0.18, 0.37, 0.25, 0.12, 0.08),
}


# ---------------------------------------------------------------- situation keys
def situation_key(street: str, raises: int, facing: bool, players_in_hand: int) -> str:
    if street == "preflop":
        return "pre:" + ("unopened" if raises == 0 else "raised" if raises == 1 else "reraised")
    return f"{street}:{'bet' if facing else 'nobet'}:{'hu' if players_in_hand <= 2 else 'mw'}"


def action_class(action: str) -> str:
    return {"fold": "fold", "check": "passive", "call": "passive", "bet": "aggressive",
            "raise": "aggressive"}[action]


def size_bin_preflop(raise_to_bb: float, faced_bb: Optional[float], unopened: bool, all_in: bool) -> Optional[int]:
    if all_in:
        return 4
    x = raise_to_bb if unopened else (raise_to_bb / faced_bb if faced_bb else None)
    if x is None:
        return None
    return 0 if x < 2.5 else 1 if x < 3.5 else 2 if x < 5 else 3


def size_bin_postflop(pot_fraction: Optional[float], all_in: bool) -> Optional[int]:
    if all_in:
        return 4
    if pot_fraction is None:
        return None
    return 0 if pot_fraction < 0.4 else 1 if pot_fraction < 0.8 else 2 if pot_fraction < 1.3 else 3


# ---------------------------------------------------------------- fitting
def record_weight(r: dict, include_highlights: bool) -> float:
    if r["selection"] == "highlight" and not include_highlights:
        return 0.0
    w = {"high": 1.0, "medium": 0.8, "low": 0.5}.get(r["confidence"], 0.5)
    if r["selection"] == "highlight":
        w *= 0.2
    if not r["action_certain"]:
        w *= 0.5
    return w


def record_situation(r: dict) -> Optional[str]:
    raises = sum(1 for a in r["previous_actions"] if a["street"] == r["street"] and a["action"] in ("bet", "raise"))
    return situation_key(r["street"], raises, r["facing_bet"], r["players_in_hand"])


def fit(records: List[dict], include_highlights: bool = False, split: str = "train") -> dict:
    counts: Dict[str, List[float]] = {k: [0.0, 0.0, 0.0] for k in PRIOR_ACTIONS}
    size_counts: Dict[str, List[float]] = {k: [0.0] * 5 for k in PRIOR_SIZES}
    used = skipped = 0
    for r in records:
        if split and f"split:{split}" not in r["flags"]:
            continue
        w = record_weight(r, include_highlights)
        if w == 0:
            skipped += 1
            continue
        key = record_situation(r)
        if key not in counts:
            continue
        counts[key][ACTIONS.index(action_class(r["action"]))] += w
        used += 1
        if r["action"] in ("bet", "raise"):
            if r["street"] == "preflop":
                faced = next((a["to_bb"] for a in reversed(r["previous_actions"])
                              if a["street"] == "preflop" and a["action"] == "raise"), None)
                b = None if r["amount_to_bb"] is None and not r["all_in"] else size_bin_preflop(
                    r["amount_to_bb"], faced, key == "pre:unopened", r["all_in"])
                fam = "pre"
            else:
                b = size_bin_postflop(r["pot_fraction"], r["all_in"])
                fam = "post"
            if b is not None:
                size_counts[fam][b] += w

    cells = {}
    for key, prior in PRIOR_ACTIONS.items():
        alpha = [p * PRIOR_STRENGTH for p in prior]
        post = [a + c for a, c in zip(alpha, counts[key])]
        z = sum(post)
        n = sum(counts[key])
        cells[key] = {
            "probs": {a: round(p / z, 4) for a, p in zip(ACTIONS, post)},
            "prior": dict(zip(ACTIONS, prior)),
            "n_measured": round(n, 2),
            "label": "measured" if n >= 30 else "mixed" if n >= 5 else "assumed",
        }
    sizes = {}
    for fam, prior in PRIOR_SIZES.items():
        post = [p * PRIOR_STRENGTH + c for p, c in zip(prior, size_counts[fam])]
        z = sum(post)
        n = sum(size_counts[fam])
        sizes[fam] = {"probs": {b: round(p / z, 4) for b, p in zip(SIZE_BINS, post)},
                      "prior": dict(zip(SIZE_BINS, prior)), "n_measured": round(n, 2),
                      "label": "measured" if n >= 30 else "mixed" if n >= 5 else "assumed"}
    return {
        "name": "Keating-inspired opponent model",
        "disclaimer": "Inspired by public broadcast play; not a reproduction of Alan Keating's strategy. "
                      "Cells labeled 'assumed' come from the prior, not data.",
        "include_highlights": include_highlights,
        "decisions_used": used, "decisions_excluded": skipped,
        "prior_strength": PRIOR_STRENGTH,
        "sanity_targets": SANITY_TARGETS,
        "assumptions": {
            "hand_strength_link": "Within a situation, stronger hands take more aggressive actions; with "
                                  "probability `unpredictability` the action ignores hand strength.",
            "unpredictability": 0.35,
            "sizing_independent_of_strength": True,
            "short_stack": "At <= 12 bb effective, aggressive preflop actions become all-ins.",
            "format_gap": "Source games are deep (often 200+ bb), ~9-handed, straddled cash games; ours is an "
                          "8-max sit-and-go that is mostly played at 10-40 bb. Preflop looseness is carried "
                          "over; deep-stack postflop patterns may not transfer.",
        },
        "actions": cells,
        "sizes": sizes,
    }


def load_records(path: str = DECISIONS) -> List[dict]:
    if not os.path.exists(path):
        return []
    with open(path) as f:
        return [json.loads(l) for l in f if l.strip()]


def load_model(path: str = MODEL_PATH) -> dict:
    with open(path) as f:
        return json.load(f)


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    cmd = argv[0] if argv else "fit"
    if cmd == "fit":
        model = fit(load_records(), include_highlights="--include-highlights" in argv)
        os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
        with open(MODEL_PATH, "w") as f:
            json.dump(model, f, indent=1)
        print(f"wrote {MODEL_PATH}: {model['decisions_used']} decisions used, "
              f"{model['decisions_excluded']} excluded (highlights)")
        cmd = "report"
    if cmd == "report":
        m = load_model()
        print(f"{'situation':16s} {'fold':>6s} {'pass':>6s} {'aggr':>6s}   n_measured  label")
        for k, c in m["actions"].items():
            p = c["probs"]
            print(f"{k:16s} {p['fold']:6.2f} {p['passive']:6.2f} {p['aggressive']:6.2f}   {c['n_measured']:10.1f}  {c['label']}")
        for fam, c in m["sizes"].items():
            print(f"sizes:{fam:10s} " + " ".join(f"{b}={v:.2f}" for b, v in c["probs"].items())
                  + f"   n={c['n_measured']}  {c['label']}")


if __name__ == "__main__":
    main()
