"""
Bluffing for the practice bots.

A bot keeps its own value logic and asks the BluffBrain only when that logic would check or fold
(or just call with a draw). The brain looks for the spots where real players bluff:

  preflop   steal from late position with weak hands; light 3-bet with suited/connected hands
  flop      continuation-bet with air as the preflop raiser; semi-bluff draws
  turn      barrel again after betting the flop, more often with a draw
  river     bluff missed draws and air heads-up, sized big (polarized)
  vs a bet  semi-bluff raise with strong draws; rare river bluff-raise against small bets

How often depends on the bot's style profile, and every frequency shrinks in multiway pots
(bluffs need everyone to fold). Bluffs never put in more than half the stack unless the bot is
already short, so a bluff doesn't turn into a reckless all-in.
"""
from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Optional

from bot.cards import HIGH, _draw_code, category, evaluate
from bot.tables import postflop_equity, preflop_pct

from .engine import CALL, CHECK, FOLD, RAISE, Action


@dataclass(frozen=True)
class BluffStyle:
    steal: float          # open-raise a weak hand from late position
    light_3bet: float     # 3-bet a suited/connected hand that would fold
    cbet_air: float       # flop c-bet with nothing as the preflop raiser
    semi_bet: float       # bet a draw when checked to
    semi_raise: float     # raise a strong draw facing a bet
    barrel: float         # bet the turn again after betting the flop, with air or a draw
    river_bluff: float    # bet the river with air / a missed draw heads-up
    multiway: float = 0.45  # multiplier per extra opponent


STYLES = {
    "tag":           BluffStyle(steal=0.30, light_3bet=0.06, cbet_air=0.55, semi_bet=0.60, semi_raise=0.20, barrel=0.35, river_bluff=0.25),
    "nit":           BluffStyle(steal=0.05, light_3bet=0.00, cbet_air=0.25, semi_bet=0.30, semi_raise=0.05, barrel=0.10, river_bluff=0.05),
    "loose-passive": BluffStyle(steal=0.00, light_3bet=0.00, cbet_air=0.10, semi_bet=0.15, semi_raise=0.00, barrel=0.05, river_bluff=0.05),
    "stand-in":      BluffStyle(steal=0.25, light_3bet=0.05, cbet_air=0.50, semi_bet=0.55, semi_raise=0.15, barrel=0.30, river_bluff=0.20),
}


def _raise_to(obs, to) -> Optional[Action]:
    if RAISE not in obs.legal:
        return None
    return Action(RAISE, int(max(obs.min_raise_to, min(obs.max_raise_to, to))))


class BluffBrain:
    def __init__(self, style: BluffStyle, rng: random.Random):
        self.s = style
        self.rng = rng

    def _roll(self, p: float, n_opp: int) -> bool:
        return self.rng.random() < p * (self.s.multiway ** max(0, n_opp - 1))

    def maybe_bluff(self, obs, normal: Action) -> Action:
        """Return a bluff instead of `normal` when the spot calls for one; otherwise `normal`."""
        if RAISE not in obs.legal or normal.kind == RAISE:
            return normal
        try:
            alt = self._preflop(obs, normal) if obs.street == 0 else self._postflop(obs, normal)
        except Exception:
            return normal
        return alt or normal

    # ------------------------------------------------------------------ preflop
    def _preflop(self, obs, normal) -> Optional[Action]:
        bb = obs.bb
        stack_bb = (obs.my_stack + obs.my_bet) / bb
        if stack_bb < 15:
            return None
        raises = [a for st, s, a in obs.history if st == 0 and a.kind == RAISE]
        hole = obs.hole
        pct = preflop_pct(hole)
        n_opp = sum(obs.in_hand) - 1
        if not raises:
            if normal.kind not in (FOLD, CHECK):
                return None
            late = len(obs.to_act_after) <= 2
            if late and pct >= 0.30 and self._roll(self.s.steal, 1):
                return _raise_to(obs, obs.my_bet + obs.to_call + 1.5 * bb + bb)   # 2.5 bb open
            return None
        if len(raises) == 1 and obs.to_call <= 0.08 * obs.my_stack:
            suited = (hole[0] & 3) == (hole[1] & 3)
            r1, r2 = hole[0] >> 2, hole[1] >> 2
            connected = abs(r1 - r2) <= 2
            if (suited and (connected or max(r1, r2) == 12)) and pct >= 0.40 and self._roll(self.s.light_3bet, n_opp):
                return _raise_to(obs, 3 * (obs.my_bet + obs.to_call))
        return None

    # ------------------------------------------------------------------ postflop
    def _postflop(self, obs, normal) -> Optional[Action]:
        seat, st = obs.seat, obs.street
        n_opp = sum(obs.in_hand) - 1
        if n_opp < 1:
            return None
        eq = postflop_equity(obs.hole, obs.board, 1)
        draw = _draw_code(obs.hole, obs.board) if st < 3 else 0
        strong_draw = draw >= 3 or (draw == 2 and st == 1)
        air = eq < 0.40 and draw == 0
        pre_aggr = any(s == seat and a.kind == RAISE for t, s, a in obs.history if t == 0)
        prev_aggr = any(s == seat and a.kind == RAISE for t, s, a in obs.history if t == st - 1)
        pot, tc = obs.pot, obs.to_call
        stack_total = obs.my_stack + obs.my_bet
        short = stack_total <= 12 * obs.bb

        def bet(frac):
            to = obs.my_bet + tc + frac * (pot + tc)
            if not short and to - obs.my_bet > 0.5 * stack_total:
                return None                       # don't bluff off half the stack
            return _raise_to(obs, to)

        if tc == 0:
            if st == 1 and pre_aggr and air and self._roll(self.s.cbet_air, n_opp):
                return bet(self.rng.choice((0.33, 0.5)))
            if draw >= 2 and self._roll(self.s.semi_bet, n_opp):
                return bet(self.rng.choice((0.5, 0.66)))
            if st == 2 and prev_aggr and (air or draw >= 2):
                p = self.s.barrel * (1.3 if draw >= 2 else 1.0)
                if self._roll(p, n_opp):
                    return bet(0.66)
            if st == 3 and n_opp == 1 and eq < 0.30:
                p = self.s.river_bluff * (1.4 if prev_aggr else 1.0)
                if self._roll(p, 1):
                    return bet(self.rng.choice((0.75, 1.0)))
            return None

        # facing a bet
        b = tc / max(1, pot - tc)                 # their bet as a fraction of the pot before it
        if strong_draw and b <= 1.0 and self._roll(self.s.semi_raise, n_opp):
            to = 3 * (obs.my_bet + tc)
            if short or to - obs.my_bet <= 0.5 * stack_total:
                return _raise_to(obs, to)
        if st == 3 and n_opp == 1 and air and b <= 0.35 and self._roll(self.s.semi_raise * 0.3, 1):
            to = 3 * (obs.my_bet + tc)
            if to - obs.my_bet <= 0.5 * stack_total:
                return _raise_to(obs, to)
        return None


# ---------------------------------------------------------------- labelling (for the app)
def classify_aggression(hole, board, street: int) -> str:
    """'value', 'semi-bluff', 'bluff' or 'thin' for a bet/raise made with `hole` on `board`."""
    if street == 0:
        return "bluff" if preflop_pct(hole) < 0.40 else "value"
    eq = postflop_equity(hole, board, 1)
    draw = _draw_code(hole, board) if street < 3 else 0
    unmade = draw >= 2 and category(evaluate(list(hole) + list(board))) == HIGH   # draws only exist before the river
    if draw >= 2 and unmade:
        return "semi-bluff"      # a drawing hand bets to win now or improve later, even with decent equity
    if eq >= 0.55:
        return "value"
    if draw >= 2:
        return "semi-bluff"
    if eq < 0.40:
        return "bluff"
    return "thin"
