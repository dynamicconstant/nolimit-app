"""PUBLIC EDITION: the frozen baseline is the competition bot, so it is not published either."""
from bot.agent import NoLimitAgent


class BaselineAgent(NoLimitAgent):
    name = "nolimit-baseline"
