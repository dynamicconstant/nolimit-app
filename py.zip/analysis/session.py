"""
Runs a game inside the browser (Pyodide) or anywhere else without a server.

GameSession wraps Table.run(): step() advances play until the human must act or the game
ends; act() feeds the human's move. Every engine event is collected as a plain dict so the
UI can replay it. At the end of each hand it builds the analyzer's hand record (with every
player's cards) and attaches the analysis.
"""
from __future__ import annotations

import random
from typing import Dict, List, Optional

from arena.engine import CALL, CHECK, FOLD, RAISE, Action, Table, TableConfig
from arena.run import BOTS
from analysis.analyzer import analyze
from bot.cards import category, evaluate

HAND_NAMES = ["High card", "Pair", "Two pair", "Three of a kind", "Straight", "Flush",
              "Full house", "Four of a kind", "Straight flush"]
DEFAULT_TABLE_FIELD = ["tag", "pusher", "nit", "station", "random", "tag", "loose-passive"]


def card_str(c: int) -> str:
    return "23456789TJQKA"[c // 4] + "cdhs"[c % 4]


class HumanSeat:
    human = True
    name = "you"


class GameSession:
    def __init__(self, mode="heads-up", opponents=None, seed=None, stack=2000, reveal=True):
        self.seed = int(seed) if seed not in (None, "") else random.randrange(10 ** 6)
        rng = random.Random(self.seed)
        if opponents:
            opp = [o for o in opponents if o in BOTS][:7]
        elif mode == "table":
            opp = ["nolimit", "maniac"] + rng.sample(DEFAULT_TABLE_FIELD, 5)
        elif mode == "maniac":
            opp = ["maniac"]
        else:
            opp = ["nolimit"]
        if not opp:
            opp = ["nolimit"]
        n = len(opp) + 1
        self.hero = rng.randrange(n)
        self.names, bots, counts, k = [], [], {}, 0
        for s in range(n):
            if s == self.hero:
                self.names.append("You")
                bots.append(HumanSeat())
                continue
            nm = opp[k]
            k += 1
            counts[nm] = counts.get(nm, 0) + 1
            label = "Bot" if nm == "nolimit" else nm
            self.names.append(label if counts[nm] == 1 else f"{label} {counts[nm]}")
            bots.append(BOTS[nm](rng.randrange(1 << 30)))
        self.cfg = TableConfig(seats=n, starting_stack=int(stack), enforce_time=False)
        self.table = Table(bots, self.cfg, random.Random(rng.randrange(1 << 30)))
        self.table.listener = self
        self.reveal = reveal
        self.options = {"mode": mode, "opponents": opp, "seed": self.seed, "stack": int(stack)}
        self.events: List[dict] = []
        self.gen = self.table.run()
        self.pending = None
        self.over = False
        self._hand = None       # record of the hand in progress (for the analyzer)

    # ------------------------------------------------------------------ driving
    def meta(self) -> dict:
        return {"names": self.names, "hero": self.hero, "seats": len(self.names), "options": self.options,
                "hands_per_level": self.cfg.hands_per_level, "max_hands": self.cfg.max_hands,
                "payouts": list(self.cfg.payouts)}

    def start(self) -> List[dict]:
        return self._advance(None)

    def act(self, kind: str, amount: int = 0) -> List[dict]:
        obs = self.pending
        if obs is None:
            raise ValueError("not your turn")
        if kind == CALL and CHECK in obs.legal:
            kind = CHECK
        if kind not in obs.legal:
            raise ValueError(f"{kind} is not legal now")
        if kind == RAISE:
            amount = int(amount)
            if not obs.min_raise_to <= amount <= obs.max_raise_to:
                raise ValueError(f"raise must be to between {obs.min_raise_to} and {obs.max_raise_to}")
        self.pending = None
        return self._advance(Action(kind, amount if kind == RAISE else 0))

    def _advance(self, action: Optional[Action]) -> List[dict]:
        if self.over:
            return []
        try:
            obs = self.gen.send(action) if action is not None else next(self.gen)
        except StopIteration:
            self.over = True
            points = self.table.points()
            alive = self.table.alive()
            self.emit({"type": "game_over", "points": points,
                       "places": [self.table.finish.get(s) for s in range(len(self.names))],
                       "survivors": alive, "hands": self.table.hand_num,
                       "winner": alive[0] if len(alive) == 1 else None})
        else:
            self.pending = obs
            self.emit({
                "type": "your_turn", "street": obs.street, "pot": obs.pot, "to_call": obs.to_call,
                "min_raise_to": obs.min_raise_to, "max_raise_to": obs.max_raise_to,
                "legal": sorted(obs.legal), "my_bet": obs.my_bet, "my_stack": obs.my_stack,
                "bb": obs.bb, "board": [card_str(c) for c in obs.board],
            })
        out, self.events = self.events, []
        return out

    def emit(self, ev: dict):
        self.events.append(ev)

    # ------------------------------------------------------------------ engine hooks
    def on_deal(self, table, hole, sb_seat, bb_seat, sb, bb, start, stacks, bets):
        level = min(table.hand_num // self.cfg.hands_per_level, len(self.cfg.blinds) - 1)
        nxt = self.cfg.hands_per_level - table.hand_num % self.cfg.hands_per_level
        n = len(self.names)
        self._hand = {
            "sb": sb, "bb": bb, "seats": n, "hero": self.hero, "button": table.button,
            "names": list(self.names), "start_stacks": list(start),
            "hole": {str(s): [card_str(c) for c in h] for s, h in hole.items()},
            "board": [], "actions": [], "sb_seat": sb_seat, "bb_seat": bb_seat,
            "seats_dealt": sorted(hole),
        }
        self.emit({"type": "hand_start", "hand": table.hand_num + 1, "button": table.button,
                   "sb_seat": sb_seat, "bb_seat": bb_seat, "sb": sb, "bb": bb, "level": level + 1,
                   "hands_to_next_level": nxt if level + 1 < len(self.cfg.blinds) else None,
                   "start_stacks": start, "stacks": stacks, "bets": bets,
                   "dealt": [s in hole for s in range(n)], "players_left": len(hole),
                   "hole": [card_str(c) for c in hole[self.hero]] if self.hero in hole else None})

    def on_action(self, table, street, seat, action, stacks, bets, pot, in_hand):
        self._hand["actions"].append({"street": street, "seat": seat, "kind": action.kind,
                                      "to": action.amount if action.kind == RAISE else None})
        self.emit({"type": "action", "street": street, "seat": seat,
                   "action": {"kind": action.kind, "amount": action.amount if action.kind == RAISE else 0},
                   "stacks": stacks, "bets": bets, "pot": pot, "in_hand": in_hand})

    def on_street(self, table, street, board, pot):
        self._hand["board"] = [card_str(c) for c in board]
        self.emit({"type": "street", "street": street, "board": [card_str(c) for c in board], "pot": pot})

    def on_hand_end(self, table, summary, stacks, hole=None):
        busted = [s for s in range(len(self.names)) if summary.starting_stacks[s] > 0 and stacks[s] == 0]
        board = [card_str(c) for c in summary.board]
        rec = self._hand
        rec["board"] = board
        rec["deltas"] = list(summary.deltas)
        analysis = None
        if self.hero in summary.shown or any(a["seat"] == self.hero for a in rec["actions"]):
            try:
                analysis = analyze(rec, seed=table.hand_num)
            except Exception as e:   # analysis must never break the game
                analysis = {"error": str(e), "decisions": [], "score": None}
        all_cards = {str(s): [card_str(c) for c in h] for s, h in (hole or {}).items()}
        ranks = {str(s): HAND_NAMES[category(evaluate(list(h) + list(summary.board)))]
                 for s, h in (hole or {}).items()} if len(summary.board) == 5 else {}
        self.emit({"type": "hand_end", "hand": summary.hand_num + 1, "board": board,
                   "shown": {str(s): [card_str(c) for c in h] for s, h in summary.shown.items()},
                   "shown_rank": {str(s): HAND_NAMES[category(evaluate(list(h) + list(summary.board)))]
                                  for s, h in summary.shown.items()},
                   "all_cards": all_cards if self.reveal else {}, "all_rank": ranks if self.reveal else {},
                   "deltas": list(summary.deltas), "stacks": stacks, "busted": busted,
                   "players_left": sum(1 for x in stacks if x > 0),
                   "record": rec, "analysis": analysis})
