"""Independent Chip Model (Malmuth-Harville).

Probability of finishing 1st is proportional to stack; given who finished 1st, 2nd place
is proportional among the rest, and so on. Only paid places are expanded, so with a
top-3 payout the cost is n*(n-1)*(n-2) paths instead of n!.
"""
from __future__ import annotations

from typing import List, Sequence


def icm_equity(stacks: Sequence[float], payouts: Sequence[float]) -> List[float]:
    n = len(stacks)
    pay = [p for p in payouts[:n]]
    while pay and pay[-1] == 0:
        pay.pop()
    eq = [0.0] * n
    if not pay:
        return eq
    total = float(sum(stacks))
    if total <= 0:
        return eq
    alive = [i for i in range(n) if stacks[i] > 0]

    def rec(remaining: List[int], rem_total: float, place: int, prob: float):
        if place >= len(pay) or not remaining:
            return
        p_place = pay[place]
        for i in remaining:
            pi = prob * stacks[i] / rem_total
            eq[i] += pi * p_place
            if place + 1 < len(pay) and len(remaining) > 1:
                rec([j for j in remaining if j != i], rem_total - stacks[i], place + 1, pi)

    rec(alive, total, 0, 1.0)
    return eq
