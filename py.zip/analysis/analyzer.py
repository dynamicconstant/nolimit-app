"""
Decision analyzer: scores every decision the hero made in a hand.

Works on a plain hand record (dict) so the same code analyzes hands you played against the
bots and hands you type in from a home game:

    record = {
      "sb": 10, "bb": 20, "seats": 8, "hero": 3, "button": 0,
      "names": [...8 names...], "start_stacks": [...8 ints...],
      "hole": {"3": ["As", "Kd"], "5": ["7c", "2d"]},   # hero required; others if known
      "board": ["Qs", "Jh", "2c", "9d"],                  # as far as it was dealt
      "actions": [{"street": 0, "seat": 1, "kind": "R", "to": 60}, {"street": 0, "seat": 3, "kind": "C"}, ...]
      "sb_seat": 1, "bb_seat": 2,                         # optional; derived from the button otherwise
      "seats_dealt": [0, 1, 3, 5]                         # optional; default: every seat with chips
    }

For each hero decision it estimates the chip value of every legal option (fold, check/call,
a few raise sizes, plus the exact size chosen) from the bot's equity tables and a simple
fold-equity model, then scores the chosen option against the best one: 100 = best option,
lower = chips given up relative to the pot. These are estimates, not solver output: they
ignore future streets beyond a realization factor and model opponents as random-ish ranges
narrowed by their actions. Good enough to flag clear mistakes, not to settle close spots.

If other players' cards are in the record, a separate "hindsight" line says how the decision
looked against their actual hands. Hindsight never changes the score: a good decision can
lose, and a bad one can win.
"""
from __future__ import annotations

import random
from typing import Dict, List, Optional

from bot.cards import evaluate, parse, preflop_class
from bot.tables import postflop_equity, preflop_equity, preflop_pct, preflop_vs_top

FOLD, CHECK, CALL, RAISE = "F", "K", "C", "R"
STREETS = ("preflop", "flop", "turn", "river")
LABELS = ((95, "optimal"), (80, "fine"), (55, "mistake"), (0, "blunder"))


def _label(score: float) -> str:
    for cut, name in LABELS:
        if score >= cut:
            return name
    return "blunder"


def position_name(seat: int, button: int, dealt: List[int]) -> str:
    """UTG, HJ, CO, BTN, SB, BB... for the seats dealt in, clockwise from the button."""
    n = len(dealt)
    order = sorted(dealt, key=lambda s: (s - button) % max(1, 100))
    order = [s for s in sorted(dealt, key=lambda s: ((s - button) % 1000))]
    rel = order.index(seat)                      # 0 = button
    if n == 2:
        return "BTN/SB" if rel == 0 else "BB"
    names = {0: "BTN", 1: "SB", 2: "BB"}
    if rel in names:
        return names[rel]
    from_end = n - rel                            # 1 = cutoff
    late = {1: "CO", 2: "HJ", 3: "LJ"}
    if from_end in late and n >= 5:
        return late[from_end]
    return "UTG" if rel == 3 else f"UTG+{rel - 3}"


def _hand_vs_hands_mc(hero, villains, board, rng, trials=240) -> float:
    """Equity of hero's exact hand vs the villains' exact hands, runouts sampled (pure Python)."""
    dead = set(hero) | set(board)
    for v in villains:
        dead |= set(v)
    deck = [c for c in range(52) if c not in dead]
    need = 5 - len(board)
    if need == 0:
        trials = 1
    total = 0.0
    for _ in range(trials):
        runout = list(board) + (rng.sample(deck, need) if need else [])
        mine = evaluate(list(hero) + runout)
        opp = [evaluate(list(v) + runout) for v in villains]
        best = max(opp)
        if mine > best:
            total += 1.0
        elif mine == best:
            total += 1.0 / (1 + sum(1 for o in opp if o == mine))
    return total / trials


class Analyzer:
    def __init__(self, seed: int = 0):
        self.rng = random.Random(seed)

    # ------------------------------------------------------------------ public
    def analyze(self, rec: dict) -> dict:
        hero = int(rec["hero"])
        n = int(rec["seats"])
        bb, sb = int(rec["bb"]), int(rec.get("sb") or max(1, rec["bb"] // 2))
        start = [int(x) for x in rec["start_stacks"]]
        names = rec.get("names") or [f"Seat {i}" for i in range(n)]
        hole_all = {int(k): [parse(c) for c in v] for k, v in rec.get("hole", {}).items() if v}
        if hero not in hole_all:
            raise ValueError("hero's hole cards are required")
        hero_hole = hole_all[hero]
        board_full = [parse(c) for c in rec.get("board", [])]
        dealt = rec.get("seats_dealt") or [s for s in range(n) if start[s] > 0]
        dealt = sorted(int(s) for s in dealt)
        button = int(rec["button"])

        def next_dealt(s):
            for k in range(1, n + 1):
                t = (s + k) % n
                if t in dealt:
                    return t
            return s

        if len(dealt) == 2:
            sb_seat = int(rec.get("sb_seat", button))
            bb_seat = int(rec.get("bb_seat", next_dealt(sb_seat)))
        else:
            sb_seat = int(rec.get("sb_seat", next_dealt(button)))
            bb_seat = int(rec.get("bb_seat", next_dealt(sb_seat)))

        stacks = list(start)
        bets = [0] * n
        committed = [0] * n
        in_hand = [s in dealt for s in range(n)]
        allin = [False] * n

        def post(s, amt):
            amt = min(amt, stacks[s])
            stacks[s] -= amt
            bets[s] += amt
            committed[s] += amt
            if stacks[s] == 0:
                allin[s] = True

        post(sb_seat, sb)
        post(bb_seat, bb)
        street, high, last_raise = 0, max(bets), bb
        raises_this_street: Dict[int, int] = {}
        raisers: List[int] = []
        callers_after_raise = 0
        hero_was_aggressor = False
        decisions = []
        history_text = []

        for a in rec.get("actions", []):
            st, s, kind = int(a["street"]), int(a["seat"]), a["kind"]
            if st != street:
                street = st
                bets = [0] * n
                high, last_raise = 0, bb
                raises_this_street = {}
                raisers, callers_after_raise = [], 0
            board = board_full[: (0, 3, 4, 5)[street]]
            to_call = max(0, min(high - bets[s], stacks[s]))
            live = [o for o in range(n) if in_hand[o] and o != s]
            if s == hero:
                decisions.append(self._judge(
                    rec, hero, hero_hole, board, street, dict(
                        pot=sum(committed), to_call=to_call, my_bet=bets[s], my_stack=stacks[s], high=high,
                        min_raise_to=min(high + last_raise, bets[s] + stacks[s]), max_raise_to=bets[s] + stacks[s],
                        live=live, live_stacks={o: stacks[o] for o in live}, live_bets={o: bets[o] for o in live},
                        allin=[o for o in live if allin[o]], raisers=list(raisers),
                        callers_after_raise=callers_after_raise, hero_was_aggressor=hero_was_aggressor,
                        position=position_name(hero, button, dealt), n_dealt=len(dealt), bb=bb,
                        hole_all=hole_all, names=names, chosen=a, history=list(history_text), hole=hero_hole,
                    )))
            # apply
            if kind == FOLD:
                in_hand[s] = False
                history_text.append(f"{names[s]} folds")
            elif kind == CHECK:
                history_text.append(f"{names[s]} checks")
            elif kind == CALL:
                post(s, to_call)
                if raisers:
                    callers_after_raise += 1
                history_text.append(f"{names[s]} calls {to_call}")
            elif kind == RAISE:
                to = int(a.get("to") or a.get("amount") or 0)
                to = max(to, bets[s] + 1)
                raise_by = to - high
                if raise_by >= last_raise:
                    last_raise = raise_by
                post(s, to - bets[s])
                high = max(high, bets[s])
                raises_this_street[s] = raises_this_street.get(s, 0) + 1
                raisers.append(s)
                callers_after_raise = 0
                if s == hero:
                    hero_was_aggressor = True
                history_text.append(f"{names[s]} {'bets' if street > 0 and len(raisers) == 1 else 'raises to'} {to}")

        scores = [d["score"] for d in decisions]
        avg = round(sum(scores) / len(scores), 1) if scores else None
        worst = min(decisions, key=lambda d: d["score"]) if decisions else None
        return {
            "decisions": decisions,
            "score": avg,
            "label": _label(avg) if avg is not None else None,
            "n_decisions": len(decisions),
            "worst": {"street": worst["street"], "label": worst["label"], "why": worst["why"]} if worst else None,
            "note": "Scores compare each decision with the best estimated option at the time; "
                    "hindsight lines use cards you could not see.",
        }

    # ------------------------------------------------------------------ one decision
    def _judge(self, rec, hero, hole, board, street, c) -> dict:
        bb = c["bb"]
        n_opp = max(1, len(c["live"]))
        pot, tc = c["pot"], c["to_call"]
        facing = tc > 0
        n_raises = len(c["raisers"])
        # ---- equity estimate at decision time
        unopened = street == 0 and n_raises == 0
        if street == 0:
            if unopened:
                # a limp/check plays against ~2 callers on average; a raise is judged vs one caller
                eq = preflop_equity(hole, min(n_opp, 2))
            else:
                rng_pct = 22.0 if n_raises == 1 else 8.0 if n_raises == 2 else 4.0
                if c["high"] >= 6 * bb:
                    rng_pct *= 0.75
                eq = preflop_vs_top(hole, rng_pct) - 0.04 * (n_opp - 1)
        else:
            eq = postflop_equity(hole, board, n_opp)
            if facing:
                b = tc / max(1, pot)
                eq = eq ** (1.0 + 0.9 * min(b, 2.0))
        eq = max(0.02, min(0.98, eq))
        realize = 1.0 if street == 3 else 0.9 if street == 2 else 0.8 if street == 1 else 0.75
        eq_r = eq * realize if not facing or tc < c["my_stack"] else eq   # all-in: no future streets

        # ---- options
        options = []
        if facing:
            options.append({"kind": FOLD, "name": "Fold", "ev": 0.0})
            call_amt = min(tc, c["my_stack"])
            ev_call = eq_r * (pot + call_amt) - (1 - eq_r) * call_amt
            options.append({"kind": CALL, "name": f"Call {call_amt}", "ev": ev_call, "to": c["my_bet"] + call_amt})
        else:
            options.append({"kind": CHECK, "name": "Check", "ev": eq_r * pot})
        can_raise = c["max_raise_to"] > c["high"] and any(c["live_stacks"][o] > 0 for o in c["live"])
        raise_sizes = []
        if can_raise:
            high = c["high"]
            if street == 0:
                if n_raises == 0:
                    raise_sizes += [("Raise to 2.5 bb", round(2.5 * bb)), ("Raise to 3.5 bb", round(3.5 * bb))]
                else:
                    raise_sizes += [("Raise to 3×", 3 * high)]
            else:
                pot_after = pot + tc
                raise_sizes += [("Bet ⅓ pot" if not facing else "Raise small", high + round(pot_after / 3)),
                                ("Bet ⅔ pot" if not facing else "Raise ⅔ pot", high + round(2 * pot_after / 3)),
                                ("Bet pot" if not facing else "Raise pot", high + pot_after)]
            raise_sizes.append(("All-in", c["max_raise_to"]))
            chosen = c["chosen"]
            if chosen["kind"] == RAISE:
                to = int(chosen.get("to") or chosen.get("amount") or 0)
                if to and all(abs(to - r[1]) > 0.02 * c["max_raise_to"] for r in raise_sizes):
                    raise_sizes.append((f"Your {'bet' if not facing and street else 'raise'} to {to}", to))
            seen = set()
            chosen_to = int(chosen.get("to") or chosen.get("amount") or 0) if chosen["kind"] == RAISE else None
            for name, to in raise_sizes:
                to = int(max(c["min_raise_to"], min(c["max_raise_to"], to)))
                if to <= high or to in seen:
                    continue
                # Postflop overbet shoves of more than 2x the pot are only priced when you actually made one:
                # the model can't value them well and they would dominate the scoring.
                if street > 0 and to - high > 2 * (pot + tc) and to != chosen_to:
                    continue
                seen.add(to)
                options.append({"kind": RAISE, "name": name if to < c["max_raise_to"] else ("All-in" if name == "All-in" else name + " (all-in)"),
                                "to": to, "ev": self._raise_ev(c, street, eq, to, n_opp)})

        chosen = c["chosen"]
        ck = chosen["kind"]
        if ck == CALL and not facing:
            ck = CHECK
        chosen_opt = None
        for o in options:
            if o["kind"] == ck and (ck != RAISE or abs(o.get("to", 0) - int(chosen.get("to") or chosen.get("amount") or 0)) <= 0.02 * c["max_raise_to"] + 1):
                chosen_opt = o
                break
        if chosen_opt is None:
            chosen_opt = next((o for o in options if o["kind"] == ck), options[0])
        best = max(options, key=lambda o: o["ev"])
        loss = best["ev"] - chosen_opt["ev"]
        scale = max(pot + tc, 4 * bb)
        score = 100.0 * max(0.0, 1.0 - loss / scale)
        if ck == best["kind"] and (ck != RAISE or chosen_opt is best):
            score = 100.0
        score = round(score, 1)
        label = _label(score)
        # name the situation
        situation = self._situation(c, street, facing, n_raises)
        why = self._why(c, street, eq, options, chosen_opt, best, situation, facing)
        hindsight = self._hindsight(hero, hole, board, street, c, chosen_opt, eq)
        return {
            "street": STREETS[street], "position": c["position"], "situation": situation,
            "board": ["23456789TJQKA"[x // 4] + "cdhs"[x % 4] for x in board],
            "pot": pot, "to_call": tc, "players_in_hand": n_opp + 1,
            "equity": round(eq, 3), "chosen": chosen_opt["name"],
            "options": [{"name": o["name"], "ev": round(o["ev"]), "best": o is best, "chosen": o is chosen_opt} for o in options],
            "best": best["name"], "score": score, "label": label, "why": why, "hindsight": hindsight,
        }

    def _raise_ev(self, c, street, eq, to, n_opp) -> float:
        """Value of raising TO `to`: everyone folds (win the pot) or one opponent continues with a
        range that gets stronger the bigger the raise, and we play on with reduced equity."""
        pot, high, bb = c["pot"], c["high"], c["bb"]
        cost = to - c["my_bet"]
        inc = to - high
        pot_after = pot + c["to_call"]
        size = inc / max(1, pot_after)                    # increment as a fraction of the pot
        all_in = to >= c["max_raise_to"]
        unopened = street == 0 and not c["raisers"]
        stack_bb = (c["my_stack"] + c["my_bet"]) / bb
        if street == 0 and all_in:
            # callers of a shove: wider against a short shove (the bot's own calling model)
            shove_bb = to / bb
            call_pct = max(3.0, min(40.0, 2.5 + 110.0 / max(1.0, shove_bb)))
            if c["raisers"]:
                call_pct = min(60.0, call_pct * 1.4)       # a raiser continues wider
            p_fold = 1.0 - call_pct / 100.0
            eq_called = preflop_vs_top(c["hole"], call_pct)
        elif unopened:
            p_fold = 0.80 if size < 3 else 0.86            # fold-to-open per player
            if stack_bb <= 12:
                p_fold *= 0.75                             # short raises get re-shoved and called light
            eq_called = preflop_vs_top(c["hole"], 16.0)    # the one who continues has a real hand
        elif street == 0:
            p_fold = max(0.3, min(0.65, 0.42 + 0.10 * min(size, 2.0)))
            if stack_bb <= 12:
                p_fold *= 0.75
            eq_called = preflop_vs_top(c["hole"], 9.0 if len(c["raisers"]) == 1 else 5.0)
        else:
            p_fold = max(0.15, min(0.8, 0.30 + 0.18 * min(size, 1.0) + 0.25 * min(max(size - 1.0, 0.0) / 3.0, 1.0)
                                    - 0.04 * (n_opp - 1)))
            eq_called = eq ** (1.5 if size <= 0.7 else 1.8 if size <= 1.05 else 2.2)
            if all_in:
                spr = (c["my_stack"] + c["my_bet"]) / max(1, pot_after)
                if spr > 1.5:                             # a big shove only gets called by strong hands
                    eq_called = min(eq_called, eq ** (1.8 + 0.3 * min(spr, 4)))
        p_all_fold = p_fold ** n_opp
        caller_stack = max(c["live_stacks"].values()) if c["live_stacks"] else 0
        caller_bet = next((c["live_bets"][o] for o, s_ in c["live_stacks"].items() if s_ == caller_stack), 0)
        called_add = max(0, min(to - caller_bet, caller_stack))
        win = pot + cost + called_add
        realize = 1.0 if (street == 3 or all_in) else 0.85
        ev_called = eq_called * realize * win - cost
        return p_all_fold * pot + (1 - p_all_fold) * ev_called

    def _situation(self, c, street, facing, n_raises) -> str:
        if street == 0:
            if n_raises == 0:
                return "unopened pot" if c["to_call"] <= c["bb"] else "limped pot"
            if n_raises == 1 and c["callers_after_raise"] >= 1:
                return "facing a raise and a call (squeeze spot)"
            if n_raises == 1:
                return "facing a raise"
            if n_raises == 2:
                return "facing a 3-bet"
            return "facing a 4-bet"
        if not facing:
            if c["hero_was_aggressor"] and not c["raisers"]:
                return "checked to you as the aggressor (c-bet spot)"
            return "checked to you" if c["my_bet"] == 0 else "action on you"
        if c["hero_was_aggressor"]:
            return "your bet was raised" if c["my_bet"] > 0 else "facing a bet after you were the aggressor"
        return "facing a bet" if n_raises == 1 else "facing a raise"

    def _why(self, c, street, eq, options, chosen, best, situation, facing) -> str:
        pct = round(100 * eq)
        n_opp = max(1, len(c["live"]))
        vs = f"against {n_opp} opponent{'s' if n_opp > 1 else ''}"
        pot, tc = c["pot"], c["to_call"]
        parts = []
        if street == 0 and not c["raisers"]:
            top = round(100 * (1 - preflop_pct(c["hole"])))
            parts.append(f"{preflop_class(c['hole'])} is in the top {max(1, top)}% of starting hands; you were {c['position']} with "
                         f"{n_opp} player{'s' if n_opp > 1 else ''} still in.")
        elif facing:
            need = round(100 * tc / (pot + tc))
            parts.append(f"You needed about {need}% equity to call and had roughly {pct}% {vs}.")
        else:
            parts.append(f"You had roughly {pct}% equity {vs}.")
        diff = round(best["ev"] - chosen["ev"])
        if chosen is best:
            parts.append(f"{chosen['name']} was the best option.")
        elif diff <= max(2, 0.03 * max(pot + tc, 4 * c["bb"])):
            parts.append(f"{chosen['name']} and {best['name'].lower()} are about equal here.")
        else:
            parts.append(f"{best['name']} was better by about {diff} chips than {chosen['name'].lower()}.")
            if best["kind"] == FOLD:
                parts.append("The price was too high for this hand.")
            elif best["kind"] == RAISE and chosen["kind"] in (CALL, CHECK):
                parts.append("Your hand had enough equity to take the initiative" +
                             (" and fold out the callers." if "squeeze" in situation else "."))
            elif best["kind"] in (CALL, CHECK) and chosen["kind"] == RAISE:
                parts.append("Raising put in chips that only stronger hands would continue against.")
            elif best["kind"] in (CALL, CHECK) and chosen["kind"] == FOLD:
                parts.append("The pot was offering enough to continue.")
        return " ".join(parts)

    def _hindsight(self, hero, hole, board, street, c, chosen, eq) -> Optional[str]:
        others = {s: h for s, h in c["hole_all"].items() if s != hero and s in c["live"]}
        if not others:
            return None
        rng = self.rng
        villains = list(others.values())
        real = _hand_vs_hands_mc(hole, villains, board, rng)
        names = [c["names"][s] for s in others]
        who = ", ".join(f"{c['names'][s]} had {_pretty(h)}" for s, h in others.items())
        pct = round(100 * real)
        line = f"{who}. Against those actual cards you had {pct}% (you estimated {round(100 * eq)}%)."
        if chosen["kind"] == FOLD:
            if real >= 0.55:
                line += " You folded the better hand, but that was not knowable: the score above judges the decision, not the outcome."
            else:
                line += " Folding also happened to be right against their actual holding."
        return line


def _pretty(cards) -> str:
    return " ".join("23456789TJQKA"[x // 4] + "♣♦♥♠"[x % 4] for x in cards)


def analyze(record: dict, seed: int = 0) -> dict:
    return Analyzer(seed).analyze(record)
